$(document).ready(function() {
//------------------------------------------------------------------------------------------
/*
if ('serviceWorker' in navigator) {
	window.addEventListener('load', function() {
		navigator.serviceWorker.register('/service-worker.js')
		.then(function(registration) {
			console.log('Service Worker registrado com sucesso:', registration);
		})
		.catch(function(error) {
			console.log('Falha ao registrar o Service Worker:', error);
		});
	});
}
*/
//------------------------------------------------------------------------------------------

let bt_marque = null;

let modalEnabled = null;

let mobmenuenabled = 0;

$('.bt_acessar_site').click(function(){
	alert('Acessar site!');
});

$('#bt_menu_marque_consulta').click(function(){
	$("#box_marque_consulta").slideToggle();
	if(bt_marque === 1) { bt_marque = 0; } else { bt_marque = 1; }
});


$(document).keyup(function(e) {
	if (e.key === "Escape") { // escape key maps to keycode `27`
		if(bt_marque === 1) {
			$("#bt_menu_marque_consulta").trigger("click");
			bt_marque = 0;
		}
		if(mobmenuenabled === 1) {
			$("#enable_menu").trigger("click");
		}
		if(modalEnabled === 1) {
			$("#close_modal").trigger("click");
		}
	}
	
});


$("#enable_menu").change(function() {
	if(this.checked) {
		console.log("Está ativo");
		$("body").css("overflow","hidden");
		$("#mobile_menu").slideToggle();
		mobmenuenabled = 1;
	} else {
		console.log("Desativado");
		$("body").css("overflow","auto");
		$("#mobile_menu").slideToggle();
		mobmenuenabled = 0;
	}
});

/**
 * Função para carregar imagens em tamanho real com base em thumbs e Intersection Observer.
 */
function preloadImagens() {
	// Seleciona todas as imagens com a classe 'preload'.
	const imagensPreload = document.querySelectorAll('.preload');
  
	// Cria um Intersection Observer para verificar a visibilidade das imagens.
	const observer = new IntersectionObserver((entries, observer) => {
	  entries.forEach(entry => {
		// Verifica se a imagem está visível na viewport.
		if (entry.isIntersecting) {
		  const img = entry.target;
  
		  // Obtém o nome da imagem thumb.
		  const srcThumb = img.src;
  
		  // Remove "_thumb" do nome da imagem para obter o nome da imagem original.
		  const srcOriginal = srcThumb.replace('_thumb', '');
  
		  // Cria um novo elemento de imagem com a URL original.
		  const novaImagem = new Image();
		  novaImagem.src = srcOriginal;
  
		  // Quando a imagem original carregar, substitui a thumb pela imagem original.
		  novaImagem.onload = () => {
			img.src = srcOriginal;
  
			// Remove o atributo class para evitar recarregamento.
			img.classList.remove('preload');
			img.classList.add('preload-ok');
  
			// Para de observar a imagem após o carregamento.
			observer.unobserve(img);
		  };
  
		  // Tratamento de erro caso a imagem original não carregue.
		  novaImagem.onerror = () => {
			console.error(`Erro ao carregar imagem: ${srcOriginal}`);
  
			// Remove o atributo class para evitar tentativas repetidas de carregamento.
			img.classList.remove('preload');
  
			// Para de observar a imagem após o erro.
			observer.unobserve(img);
		  };
		}
	  });
	}, {
	  // Opções do Intersection Observer (opcional).
	  root: null, // Observa a viewport por padrão.
	  rootMargin: '0px', // Sem margem.
	  threshold: 0 // Dispara quando qualquer parte da imagem estiver visível.
	});
  
	// Observa cada imagem com a classe 'preload'.
	imagensPreload.forEach(img => {
	  observer.observe(img);
	});
  }
  
  
  // Chama a função para iniciar o preload das imagens.
  preloadImagens();
  
  

/*

let statusConexao = null;

    const verificarConexao = () => {
        // Faz uma requisição a um recurso pequeno e confiável
        fetch('https://www.google.com/favicon.ico', { mode: 'no-cors', cache: 'no-store' }) // no-cors para evitar problemas de CORS
            .then(() => {
                if (!statusConexao) { // Se estava offline, agora está online
                    statusConexao = true;
                    console.log('Conexão: Online');
                    // Lógica para quando estiver online (ex: sincronizar dados)
                }
            })
            .catch(() => {
                if (statusConexao) { // Se estava online, agora está offline
                    statusConexao = false;
                    console.log('Conexão: Offline');
                    // Lógica para quando estiver offline (ex: exibir mensagem)
                }
            });
    };

    // Verificação inicial
    verificarConexao();

    // Verificações periódicas (a cada 5 segundos)
    setInterval(verificarConexao, 5000);

    // Event listeners para mudanças rápidas (combinado com a verificação periódica)
    window.addEventListener('online', verificarConexao);
    window.addEventListener('offline', verificarConexao);

*/









//------------------------------------------------------------------------------------------
// buscar especialidades

function normalizeString(str) {
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

const searchInput = document.getElementById('buscar_especialidade');

if (searchInput) {
    let normalizedSearchText = "";
    const searchAreas = Array.from(document.querySelectorAll('.master_search'));
    const checkItensDivs = [];

    for (let i = 0; i < searchAreas.length; i++) {
        checkItensDivs.push(document.getElementById(`checkItens${i + 1}`));
    }

    const handleInput = function (event) {
        normalizedSearchText = normalizeString(event.target.value);
        let areaIndex = 0;

        for (const area of searchAreas) {
            const divs = Array.from(area.querySelectorAll('div[data-filter]'));
            let hasVisibleItems = false;
            const checkItensDiv = checkItensDivs[areaIndex];

            for (const div of divs) {
                const filterValue = normalizeString(div.getAttribute('data-filter'));
                const isVisible = filterValue.includes(normalizedSearchText);

                div.style.display = isVisible ? '' : 'none';//block?
                hasVisibleItems = hasVisibleItems || isVisible;
            }

            area.style.display = hasVisibleItems ? 'grid' : 'none';


            if (checkItensDiv) {
                checkItensDiv.style.visibility = hasVisibleItems ? 'visible' : 'hidden';
            }

            areaIndex++;
        }
    };

    const resetFilter = function () {
        searchInput.value = '';
        normalizedSearchText = '';

        for (let i = 0; i < searchAreas.length; i++) {
            const area = searchAreas[i];
            const divs = area.querySelectorAll('div[data-filter]');
            divs.forEach(div => div.style.display = '');//block?

            const checkItensDiv = checkItensDivs[i];
            if (checkItensDiv) {
                checkItensDiv.style.visibility = 'visible';
            }

            area.style.display = 'grid';
        }
    };

    searchInput.addEventListener('input', handleInput);

    searchInput.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            resetFilter();
            event.preventDefault();
        }
    });
}

//------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------
// buscar unidades



const searchInput2 = document.getElementById('buscar_unidade');
let unidadesproximas = 20;
const unidades = document.querySelectorAll('.item');

if (searchInput2) {
    
    let normalizedSearchText = "";
    const searchAreas = Array.from(document.querySelectorAll('.master_search_unidades'));
    const checkItensDivs = [];

    for (let i = 0; i < searchAreas.length; i++) {
        checkItensDivs.push(document.getElementById(`checkItens${i + 1}`));
    }

    const handleInput = function (event) {
        normalizedSearchText = normalizeString(event.target.value);
        let areaIndex = 0;

        for (const area of searchAreas) {
            const divs = Array.from(area.querySelectorAll('div[data-filter]'));
            let hasVisibleItems = false;
            const checkItensDiv = checkItensDivs[areaIndex];

            for (const div of divs) {
                const filterValue = normalizeString(div.getAttribute('data-filter'));
                const isVisible = filterValue.includes(normalizedSearchText);

                div.style.display = isVisible ? '' : 'none';//block?
                hasVisibleItems = hasVisibleItems || isVisible;
            }

            area.style.display = hasVisibleItems ? 'grid' : 'none';


            if (checkItensDiv) {
                checkItensDiv.style.visibility = hasVisibleItems ? 'visible' : 'hidden';
            }

            areaIndex++;
        }
    };

    const resetFilter2 = function () {
        searchInput2.value = '';
        normalizedSearchText = '';

        for (let i = 0; i < searchAreas.length; i++) {
            const area = searchAreas[i];
            const divs = area.querySelectorAll('div[data-filter]');
            divs.forEach(div => div.style.display = '');//block?

            const checkItensDiv = checkItensDivs[i];
            if (checkItensDiv) {
                checkItensDiv.style.visibility = 'visible';
            }

            area.style.display = 'grid';
        }
    };

    searchInput2.addEventListener('input', handleInput);

    searchInput2.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') {
            resetFilter2();
            event.preventDefault();
        }
    });
}

//##### UNIDADES MAIS PRÓXIMAS:

// Função para calcular a distância entre dois pontos geográficos usando a fórmula de Haversine
function calcularDistancia(lat1, lon1, lat2, lon2) {
    const R = 6371; // Raio da Terra em km
    const dLat = (lat2 - lat1) * Math.PI / 180; // Converte a diferença de latitude para radianos
    const dLon = (lon2 - lon1) * Math.PI / 180; // Converte a diferença de longitude para radianos
    const lat1Rad = lat1 * Math.PI / 180; // Converte latitude inicial para radianos
    const lat2Rad = lat2 * Math.PI / 180; // Converte latitude final para radianos

    // Fórmula de Haversine
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1Rad) * Math.cos(lat2Rad) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distância em km
}

// Função para exibir as unidades mais próximas
function exibirUnidadesProximas(latitudeUsuario, longitudeUsuario) {
    const container = document.querySelector('.master_search_unidades');
    const unidades = Array.from(container.querySelectorAll('.item')); // Melhoria: converte para array uma única vez

    // Verifica se há mais de 20 itens no container + unidadesproximas
    if (unidades.length > (unidadesproximas + 1)) { // +1 porque unidadesproximas é um valor numérico
        const unidadesComDistancia = unidades.map(unidade => {
            const latitudeUnidade = parseFloat(unidade.dataset.lat);
            const longitudeUnidade = parseFloat(unidade.dataset.long);
            const distancia = calcularDistancia(latitudeUsuario, longitudeUsuario, latitudeUnidade, longitudeUnidade);

            return { unidade, distancia };
        });

        unidadesComDistancia.sort((a, b) => a.distancia - b.distancia);

        // Oculta as unidades originais e adiciona os clones em uma única iteração
        unidadesComDistancia.forEach((item, index) => {
            item.unidade.style.display = 'none';

            if (index < unidadesproximas) {
                const clone = item.unidade.cloneNode(true);
                clone.classList.add('listatemporaria');
                clone.style.display = ''; // Garante que o clone esteja visível

                // Adiciona a distância ao clone
                const distanciaSpan = clone.querySelector('.distancia_unidades');
                if (distanciaSpan) {
                    distanciaSpan.textContent = `Distância aproximada: ${item.distancia.toFixed(2)} km`;
                }

                container.appendChild(clone);
            }
        });

        $('.group_loader').css({"display":"none"});
        $('#bt_limpar_lista_temporaria').css({"display":"flex"});
    } else {
        console.log('Unidades próximas já sendo exibidas!');
    }
}

// Função para limpar a lista temporária e exibir todos os itens (otimizada)
function limparListaTemporaria() {
    const container = document.querySelector('.master_search_unidades');

    // Remove todos os elementos temporários de uma vez
    const temporarios = container.querySelectorAll('.listatemporaria');
    temporarios.forEach(temporario => temporario.remove());

    // Exibe todos os itens originais de uma vez
    const unidades = container.querySelectorAll('.item');
    container.style.display = 'none'; // Oculta o container para evitar reflows
    unidades.forEach(unidade => unidade.style.display = '');
    container.style.display = ''; // Exibe o container novamente

    hideGeoUnidade();
}


// Adiciona evento de clique ao botão 'bt_unidades_proximas'
const botaoUnidadesProximas = document.getElementById('bt_unidades_proximas');

if (botaoUnidadesProximas) {
    botaoUnidadesProximas.addEventListener('click', () => {
        if (document.querySelectorAll('.item').length > unidadesproximas) { // Verifica se há unidades suficientes
            console.log('Solicitando geo do visitante...');
            showGeoUnidade();
            navigator.geolocation.getCurrentPosition(
                (posicao) => {
                    const latitudeUsuario = posicao.coords.latitude;
                    const longitudeUsuario = posicao.coords.longitude;
                    console.log('Geolocation ok!');

                    exibirUnidadesProximas(latitudeUsuario, longitudeUsuario);
                },
                (erro) => {
                    console.error('Erro ao obter a localização:', erro);
                    hideGeoUnidade();
                    // Trate o erro de acordo com a necessidade da sua aplicação
                }
            );
        } else {
            console.log('Unidades mínimas não alcançadas!');
        }
    });
}

// Adiciona evento de clique ao botão 'bt_limpar_lista_temporaria'
const botaoLimparLista = document.getElementById('bt_limpar_lista_temporaria');
if (botaoLimparLista) {
    botaoLimparLista.addEventListener('click', limparListaTemporaria);
}


function showGeoUnidade() {
    $('.areas-search').css({"visibility":"hidden"});
    $('#bt_limpar_lista_temporaria').css({"display":"none"});
    $('#bt_unidades_proximas').css({"display":"none"});
    $('.group_loader').css({"display":"flex"});
    $('#txt_unidades_proximas').css({"display":"block"});
}

function hideGeoUnidade() {
    $('.areas-search').css({"visibility":"visible"});
    $('#bt_limpar_lista_temporaria').css({"display":"none"});
    $('#bt_unidades_proximas').css({"display":"flex"});
    $('.group_loader').css({"display":"none"});
    $('#txt_unidades_proximas').css({"display":"none"});
}

//------------------------------------------------------------------------------------------
// Seleciona todos os widgets do youtube
const widgets = document.querySelectorAll('.youtube_widget');
const allowedAttributes = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture";

widgets.forEach(widget => {
    const img = widget.querySelector('img');
    const iframe = widget.querySelector('iframe');

    // Adiciona evento de clique ao widget
    widget.addEventListener('click', () => {
        img.classList.add('hideme');
        iframe.classList.remove('hideme');

        // Constrói a URL do vídeo com autoplay
        const videoURL = iframe.dataset.url + "&autoplay=1"; 
        iframe.src = videoURL;

        // Adiciona os atributos "allow" ao iframe
        iframe.setAttribute('allow', allowedAttributes);

        iframe.onload = function() {
            iframe.contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', '*');
        };
    });


    // Remove atributo allow quando o vídeo não está ativo.
    if (iframe.src === 'about:blank'){
        iframe.removeAttribute('allow')
    }

});
//------------------------------------------------------------------------------------------
$(".faq-question").on("click", function () {
    // Ocultar todas as respostas e remover classe 'active'
    $(".faq-answer").slideUp();
    $(".faq-question").removeClass("active");

    // Expandir apenas a resposta associada à pergunta clicada
    const answer = $(this).next(".faq-answer");
    if (!answer.is(":visible")) {
      answer.slideDown();
      $(this).addClass("active");
    }
  });
//------------------------------------------------------------------------------------------
function topFunction() {
	$('html, body').animate({ scrollTop: 0 }, 'fast');
} 
//------------------------------------------------------------------------------------------
//modal
$('.closemydear').on("click", function () {
	modalEnabled = 0;
	$('#modalbg').fadeOut(250);
	$("body").css("overflow","auto");
});

$('#close_modal').on("click", function () {
	modalEnabled = 0;
	$('#modalbg').fadeOut(250);
	$("body").css("overflow","auto");
});
	
$('.saiba_mais').each(function () {
	let $this = $(this);
	$this.on("click", function () {
		$('#modal_title').text('');
		$('#modal_content').html('');
		modalEnabled = 1;
		let itemId = $(this).attr("data-item");
		fetch('/especialidades.json')
                .then(response => response.json())
                .then(data => {
                    const itemData = data.find(item => item.id === itemId);
                    if (itemData) {
						$('#modal_title').text(itemId);
						$('#modal_content').html(itemData.conteudo);
						$("body").css("overflow","hidden");
						$('#modalbg').fadeIn(250);
                    } else {
                        console.error('Dados do item não encontrados.');
                    }
                })
                .catch(error => {
                    console.error('Erro ao carregar dados:', error);
                });
		
	});
});

//------------------------------------------------------------------------------------------
// central ajuda slider


// Seleciona o container principal da central de ajuda.
const centralAjudaVerify = document.getElementById('central-ajuda');

// Verifica se o container existe no DOM.
if (centralAjudaVerify) {
    // Seleciona todos os itens de ajuda.
    const ajudaItems = document.querySelectorAll('.ajuda-item');
    // Seleciona o indicador de item ativo.
    const indicator = document.querySelector('.active-indicator');
    // Seleciona o container de conteúdo.
    const ajudaContent = document.getElementById('ajuda-content');

    // Define o item ativo inicial.
    let activeItem = document.querySelector('.ajuda-item.active');
    if (!activeItem) {
        activeItem = ajudaItems[0];
    }

    // Define o estilo inicial do indicador.
    indicator.style.top = `${activeItem.offsetTop}px`;
    indicator.style.height = `${activeItem.offsetHeight}px`;
    indicator.style.transition = 'top 0.3s ease, height 0.3s ease';

    // Adiciona um evento de clique a cada item de ajuda.
    ajudaItems.forEach((item) => {
        item.addEventListener('click', (event) => {
            // Captura o atributo 'data-item-id' do item clicado.
            const ajudaItemId = event.currentTarget.dataset.itemId;

            // Remove a classe 'active' do item ativo anterior.
            document.querySelector('.ajuda-item.active')?.classList.remove('active');

            // Adiciona a classe 'active' ao item clicado.
            item.classList.add('active');

            // Atualiza a posição e altura do indicador.
            indicator.style.top = `${item.offsetTop}px`;
            indicator.style.height = `${item.offsetHeight}px`;

            // Mostra/esconde os conteúdos com base no ajudaItemId.
            if (ajudaContent) {
                // Itera sobre os filhos diretos do container de conteúdo.
                ajudaContent.querySelectorAll(':scope > div').forEach(conteudoItem => {
                    // Verifica se o id do conteúdo corresponde ao ajudaItemId.
                    if (conteudoItem.id === ajudaItemId) {
                        conteudoItem.classList.remove('hideme');
                    } else {
                        conteudoItem.classList.add('hideme');
                    }
                });
            }
        });
    });
}


//------------------------------------------------------------------------------------------
const isFornecedor = document.getElementById('cnpj');

if (isFornecedor) {
    $('#cnpj').mask("99.999.999/9999-99");
    $('.phone').mask('(00) 00000-0000');
    $('.fonefixo').mask('(00) 0000-0000');
}
//------------------------------------------------------------------------------------------
});